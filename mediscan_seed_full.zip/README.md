# Mediscan seed (врачи + фото)

## Что внутри
- `media/doctors/*.webp` — 14 фото врачей (7 мужчин + 7 женщин), квадрат 1024×1024 WebP
- `fixtures/specialties.json` — 7 специализаций
- `fixtures/doctors.json` — 14 врачей со ссылками на фото
- `fixtures/seed_mediscan.json` — всё одним файлом (specialties + doctors)

## Как подключить в Django
1) Скопируйте папку `media/doctors` в ваш `MEDIA_ROOT`:
   - например: `your_project/media/doctors`

2) Загрузите фикстуры:
```bash
python manage.py loaddata fixtures/seed_mediscan.json
# или по отдельности:
python manage.py loaddata fixtures/specialties.json
python manage.py loaddata fixtures/doctors.json
```

## Примечания
- В фикстуре `photo` указан относительный путь `doctors/<file>.webp` — стандартно для `ImageField` при `MEDIA_ROOT`.
- Модели указаны как `staff.specialty` и `staff.doctor`.
  Если у вас другие app_label / model names — скажи, подгоню под твою схему.
